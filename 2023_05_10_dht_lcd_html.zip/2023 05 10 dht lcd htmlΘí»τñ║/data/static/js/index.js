/* js script to handle DHT stream data
*/
$(document).ready(function() {
    var sse_target_data = {}; // object is empty;
    //var temp = 0.0;
    //var humid = 0.0;
    
    // Create Temperature Gauge
    var gaugeTemp = new LinearGauge({
      renderTo: 'gauge-temperature',
      width: 120,
      height: 400,
      units: "Temperature (°C)",
      minValue: 0,
      startAngle: 90,
      ticksAngle: 180,
      maxValue: 50,
      colorValueBoxRect: "#049faa",
      colorValueBoxRectEnd: "#049faa",
      colorValueBoxBackground: "#f1fbfc",
      valueDec: 2,
      valueInt: 2,
      majorTicks: [
          "0",
          "5",
          "10",
          "15",
          "20",
          "25",
          "30",
          "35",
          "40",
          "45",
          "50"
      ],
      minorTicks: 4,
      strokeTicks: true,
      highlights: [
          {
              "from": 30,
              "to": 45,
              "color": "rgba(200, 50, 50, .75)"
          }
      ],
      colorPlate: "#fff",
      colorBarProgress: "#CC2936",
      colorBarProgressEnd: "#049faa",
      borderShadowWidth: 0,
      borders: false,
      needleType: "arrow",
      needleWidth: 2,
      needleCircleSize: 7,
      needleCircleOuter: true,
      needleCircleInner: false,
      animationDuration: 1500,
      animationRule: "linear",
      barWidth: 10,
    }).draw();
      
    // Create Humidity Gauge
    var gaugeHum = new RadialGauge({
      renderTo: 'gauge-humidity',
      width: 300,
      height: 300,
      units: "Humidity (%)",
      minValue: 0,
      maxValue: 100,
      colorValueBoxRect: "#049faa",
      colorValueBoxRectEnd: "#049faa",
      colorValueBoxBackground: "#f1fbfc",
      valueInt: 2,
      majorTicks: [
          "0",
          "20",
          "40",
          "60",
          "80",
          "100"
      ],
      minorTicks: 4,
      strokeTicks: true,
      highlights: [
          {
              "from": 80,
              "to": 100,
              "color": "#03C0C1"
          }
      ],
      colorPlate: "#fff",
      borderShadowWidth: 0,
      borders: false,
      needleType: "line",
      colorNeedle: "#007F80",
      colorNeedleEnd: "#007F80",
      needleWidth: 2,
      needleCircleSize: 3,
      colorNeedleCircleOuter: "#007F80",
      needleCircleOuter: true,
      needleCircleInner: false,
      animationDuration: 1500,
      animationRule: "linear"
    }).draw();
    
    // line chart graph setting
    const config = {
        type: 'line',
        data: {
            labels: ['DHT data'],
            datasets: [{
                label: "Temperature",
                backgroundColor: 'rgb(204, 0, 0)',
                borderColor: 'rgb(204, 0, 0)',
                data: [],
                fill: false,
            },{
               label: "Humidity",
               backgroundColor: 'rgb(0, 0, 255)',
               borderColor: 'rgb(0, 0, 255)',
               data: [],
               fill: false,
           },{
               label: "Random Number",
               backgroundColor: 'rgb(51, 255, 51)',
               borderColor: 'rgb(51, 255, 51)',
               data: [],
               fill: false,
           }],
        },
        options: {
            responsive: true,
            title: {
                display: true,
                text: '***Real-Time Chart***'
            },
            tooltips: {
                mode: 'index',
                intersect: false,
            },
            hover: {
                mode: 'nearest',
                intersect: true
            },
            scales: {
                xAxes: [{
                    display: true,
                    scaleLabel: {
                        display: true,
                        labelString: 'Time'
                    }
                }],
                yAxes: [{
                    display: true,
                    scaleLabel: {
                        display: true,
                        labelString: 'Value'
                    }
                }]
            }
        }
    };
    





function getReadings(){
    var xhr = new XMLHttpRequest();

    xhr.open("GET","/readings", true);
    xhr.send();
    xhr.onreadystatechange function() {
        if (this.readyState == 4 && this.status == 200) {
            try {
                var myObj = JSON.parse(this.responseText);
                console.log("WebEvent: first reading event object...", myObj);
                gaugeTemp.value = myObj.Temperature;
                gaugeHum.value = myObj.Humidity;
                }

        }
    }











    // Get current sensor readings when the page loads
    /*
    window.addEventListener('load', getReadings);
    
    // Function to get current readings on the webpage when it loads for the first time
    // The readyState property holds the status of the XMLHttpRequest. The response of the request is ready when the readyState is 4, and the status is 200.
    function getReadings(){
      var xhr = new XMLHttpRequest();
      // update data with the registered route "/readings in the server.on() function
      xhr.open("GET", "/readings", true);
      xhr.send();
      xhr.onreadystatechange = function() {
        //  the request is ready when .readyState=4 and status=200
        if (this.readyState == 4 && this.status == 200) {
            try {
                var myObj = JSON.parse(this.responseText);
                console.log("WebEvent: first reading event object...", myObj);
                gaugeTemp.value = myObj.Temperature;
                gaugeHum.value = myObj.Humidity;
            } catch (err) {
                //Uncaught SyntaxError: JSON.parse: unexpected character
                console.log(err.message);
            }
        }
      };
    }*/
    
    const context = document.getElementById('canvas').getContext('2d');
    const lineChart = new Chart(context, config);
    
    // server-sent-event (SSE) call-back for dht data
    // We would have to wait for new sensor readings to arrive (via Server-Sent Events), which can take some time depending on the interval that you set on the server.
    if (!!window.EventSource) {
      var source = new EventSource('/events');
      
      // Event - target - type: "open"
      source.addEventListener('open', function(e) {
        console.log("WebEvent: Events are Connected >>", e.data);
      }, false);

      // Enent - target - type: "error"
      source.addEventListener('error', function(e) {
        if (e.target.readyState != EventSource.OPEN) {
          console.log("WebEvent: Events Disconnected");
        }
      }, false);
      
     // MessageEvent  - target - type: "message"
      source.addEventListener('message', function(e) {
        // message received with "NULL" type sent from the server event: event.send(, NULL, )
        console.log("WebEvent: event message >> ", e.data);
      }, false);
      
      // MessageEvent - target -type: "web_event_new_readings"
      // corresponding to events.send(, "web_event_new_readings",) every 2 seconds in the server
      source.addEventListener('web_event_new_readings', function(e) {
        console.log("webEvent: new readings event >> ", e.data);
        try {
            sse_target_data = JSON.parse(e.data);
            var isEmpty = isEmptyObject(sse_target_data);
            if (!isEmpty) {
                console.log("WebEvent: target data >> ",sse_target_data);

                // gauges value update
                console.log("Update DHT values from webevent listerner");
                /*
                gaugeTemp.value = sse_target_data.Temperature;
                gaugeHum.value = sse_target_data.Humidity;

                // line chart: load graph data
                if (config.data.labels.length === 20) {
                    config.data.labels.shift();
                    config.data.datasets[0].data.shift();
                    config.data.datasets[1].data.shift();
                    config.data.datasets[2].data.shift();
                }
                config.data.labels.push(sse_dht_data.Time);
                config.data.datasets[0].data.push(sse_dht_data.Temperature);
                config.data.datasets[1].data.push(sse_dht_data.Humidity);
                config.data.datasets[2].data.push(sse_dht_data.RandomValue);
                lineChart.update();
                */
            }
        } catch (err) {
            //Uncaught SyntaxError: JSON.parse: unexpected character
            console.log(err.message);
        }
      }, false);
    }
    
    // refresh value: 100 ms
    setInterval (function() {
        console.log("Update target values from setInterval()");
        //gaugeTemp.value = sse_dht_data.Temperature;
        //gaugeHum.value = sse_dht_data.Humidity;
    },50);

    function isEmptyObject(obj) {
        var name;
        for (name in obj) {
            return false;
        }
        return true;
    }
});
