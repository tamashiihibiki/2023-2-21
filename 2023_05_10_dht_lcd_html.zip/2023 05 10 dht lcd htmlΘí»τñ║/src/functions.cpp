#include <Arduino.h>
#include "functions.h"

// declare prototypes
void onPageNotFound(AsyncWebServerRequest *request);
String getDHTdata_init();
String getDHTdata(float t, float h);
// Initialize SPIFFS

JSONVar dhtData_dict, dhtData_dict_init;


void initFS() {
    if (!SPIFFS.begin()) {
      Serial.println("An error has occurred while mounting SPIFFS");
    }else{
    Serial.println("SPIFFS mounted successfully");
    }
}

// Initialize WiFi
void initWiFi() {
    if (wifi_mode == "STA"){
        // configurate static ip address for STA mode: check the local ip
        byte tmp_ipv4;
        if ((ssid == "HomeResort3F") || (ssid == "LAB_I3301")) 
            tmp_ipv4 = 3;
        else if (ssid == "I2313")
            tmp_ipv4 = 3;  
        
        //IPAddress local_IP(192, 168, tmp_ipv4, random(2,254));  
        IPAddress local_IP(192, 168, tmp_ipv4, 168); 
        IPAddress gateway(192, 168, tmp_ipv4, 1);
        IPAddress subnet(255, 255, 255, 0);
        IPAddress primaryDNS(192, 168, tmp_ipv4, 254);;   //optional
        IPAddress secondaryDNS(192, 168, tmp_ipv4, 254);;   //optional
        WiFi.mode(WIFI_STA);
      
        // STA mode: Configures static IP address
        if (!WiFi.config(local_IP, gateway, subnet, primaryDNS, secondaryDNS)) {
          Serial.println("STA Failed to configure");
        }
        
        WiFi.begin(ssid, password);
        Serial.print("Connecting to WiFi ..");
        
        while (WiFi.status() != WL_CONNECTED) {
            Serial.print('.');
            delay(1000);
        }
        String IP = WiFi.localIP().toString();
        Serial.println();
        Serial.println("WiFi connected");
        //--------------------------------//
        Serial.println(String()+ "DHT Data Stream Ready! Go to: http://" + IP);
        //--------------------------------//

        //Serial.println(WiFi.localIP());
    } else { // AP mode
        // default ip address: 192.168.4.1
        //IPAddress local_IP(192, 168, 1, 168);  
        IPAddress local_IP(192, 168, 1, random(2,254));
        IPAddress gateway(192, 168, 1, 0);
        IPAddress subnet(255, 255, 255, 0);
        // Connect to Wi-Fi network with SSID and password
        Serial.println("Setting AP (Access Point) ...");
        WiFi.softAPConfig(local_IP, gateway, subnet);
        // Remove the password parameter, if you want the AP (Access Point) to be open
        WiFi.softAP(ssid, password);
    
        //IPAddress IP = WiFi.softAPIP();
        String IP = WiFi.softAPIP().toString();
        //--------------------------------//
        Serial.print(String()+"DHT Stream Ready! Connect to the ESP32-Cam AP and go to: http://");
        //--------------------------------//
        //Serial.println(IP);
    }
}

void initWebServer() {
    // Register the route “/” to the web server and will only listen to 'HTTP GET' requests.
    //server.on("/", HTTP_GET, handleRoot);
    // On HTTP request for root '/', provide index.html file
    // this tells WEB Server to send the files request by the browser that are contained in the SPIFFS Filesystem 
    // such as images, style sheets, JavaScript sources, etc. This means we don't have to deal with mime types of files requested.
    // Files saved in SPIFFS Filesystem can be revisited in the Cache memory within 600 secs rather than in the SPIFFS Filesystem.
    //server.serveStatic("/", SPIFFS, "/").setDefaultFile("index.html").setCacheControl("max-age=600");
    server.serveStatic("/", SPIFFS, "/").setDefaultFile("index.html");
    server.serveStatic("/static/TamashiiHibiki",SPIFFS, "/dht.html");
    // Handle requests for pages that do not exist
    server.onNotFound(onPageNotFound); 

    // Start web server
    server.begin();
    Serial.println("HTTP server started");
}

// AsyncWebServer Callback: send 404 if requested file does not exist
void onPageNotFound(AsyncWebServerRequest *request) {
  IPAddress remote_ip = request->client()->remoteIP();
  Serial.println("[" + remote_ip.toString() + "] HTTP GET request of " + request->url());
  request->send(404, "text/plain", "Code 404, BUG TRP CRASH");
}

// initialize WebEvent for DHT
void initWebEvent() {
    //Set up the event source on the server.
    events.onConnect([](AsyncEventSourceClient *client){
      // trigger event by EventListerned in the client (sse_dht.js) with 'open' title
      if (client->lastId()){
        Serial.printf("WebEvent: Client reconnected! Last message ID that it got is: %u\n", client->lastId());
      }
      Serial.println(String() + "WebEvent: Requested from the web for the first loading!");
      String json_string = getDHTdata_init();
      // send event with message: "WebEvent: hello from ESP32 server!", target type: NULL, id current millis, reconnect delay: 1 second
      // the event will be intercepted by EventListerned in the client (sse_dht.js) with the target type: 'message'
      client->send(json_string.c_str(),NULL, millis(), 1000);
    });
    server.addHandler(&events); // add event into the server
}













String getDHTdata_init(){
dhtData_dict_init ["Temperature"] = String (random (1, 50));
dhtData_dict_init ["Humidity"] = String(random (1,100));
dhtData_dict_init ["RandomValue"] = String(random (1,100));
dhtData_dict_init ["Time"] = String (millis());

String jsonString = JSON.stringify(dhtData_dict_init);
return jsonString;
}


String getDHTData(float t, float h){
  dhtData_dict["Temperature"] = String(t);
  dhtData_dict["Humidity"] = String(h);
  dhtData_dict["RandomValue"] = String(random (1,100));
  dhtData_dict["Time"] = String (millis());

  String jsonString = JSON.stringify(dhtData_dict);
  return jsonString;
}

//webevent: read DHT data
String readDHTData() {
// Sensor readings may also be up to 2 seconds 'old' (its a very slow sensor)
// Read temperature as Celsius (the default)
float t = dht.readTemperature();
float h = dht.readHumidity();
// Read temperature as Fahrenheit (is Fahrenheit = true)
// Check if any reads failed and exit early (to try again).
if (isnan(t) ||isnan (h)) {
  Serial.println("Failed to read from DHT sensor!");
  return String();
}
String dhtData_json = getDHTData(t, h);
Serial.println(String() + "WebEvent: reading temperature..." + t + "°C");
Serial.println(String() + "WebEvent: reading himidity " + h + "%");
return dhtData_json;
}