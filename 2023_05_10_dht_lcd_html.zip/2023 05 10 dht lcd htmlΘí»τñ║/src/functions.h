// header file
//setup “header/include guards” and prevent the duplicate-inclusion of the same file.
// https://www.learncpp.com/cpp-tutorial/header-guards/
#ifndef FUNCTIONS_H // a condition set for the preprocessor to include the header contents
#define FUNCTIONS_H

    #include <Arduino.h>
    #include <WiFi.h>
    #include <AsyncTCP.h>
    #include <ESPAsyncWebServer.h>
    #include <SPIFFS.h>
    #include <Arduino_JSON.h>
    #include <LiquidCrystal_I2C.h>
    #include <Wire.h>
    #include <DHT.h>

    // declare external functions that will be imported through the header file
    void initFS();
    void initWiFi();
    void initWebServer();
    void initWebEvent();
    String readDHTData();
    void lcd_init();
    void lcd_print(String l1_text,String l2_text);

    // declare external objects 
    extern AsyncWebServer server;
    extern AsyncEventSource events;
    extern DHT dht;
    extern LiquidCrystal_I2C lcd;
    extern const char* wifi_mode;
    extern const char int http_port;
    extern const char* ssid;  
    extern const char* password; 
#endif