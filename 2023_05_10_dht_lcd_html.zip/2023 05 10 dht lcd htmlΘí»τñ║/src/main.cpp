/*
 * 
 * SPIFFS file names can be 32 bytes max (including starting slash and zero at the end).
 * To setup the web server, we will need two libraries. 
 * 1. The first one is the 'ESPAsyncWebServer', which we will use in our code.
 * https://github.com/me-no-dev/ESPAsyncWebServer
 * 2. The second library needed is the AsyncTCP, which is a dependency for the previous one. 
 * This library is an asynchronous TCP library for the ESP32 and it is the base for the ESPAsyncWebServer library implementation
 * https://github.com/me-no-dev/AsyncTCP
 *
 *Libraries:
 * 
  Server-Sent-Events:
  https://www.theengineeringprojects.com/2022/03/server-sent-events-with-esp32-and-dht11.html
  https://randomnerdtutorials.com/esp32-web-server-gauges/

  *Execution step::
  *1. upload async_webserver_iot.ino // clean up all memory
  *2. upload /data by Sketch Data Upload Plugin
 */





#include <Arduino.h>
#include "functions.h"

const char* wifi_mode = "AP"; //"STA"/"AP";
const char* ssid;      
const char* password;
// initialize async webserver
int dhtPin = 27;
int DHTTYPE = 11;

dht(dhtPin,DHTTYPE);


idCrystal_I2C lcd(0x27, 16, 2);


const int http_port = 8080;  // default: 80
AsyncWebServer server(http_port);

// initialize an Event Source on /events to its counter part in index_dht.js
AsyncEventSource events("/events");

// Timer variables for DHT
unsigned long lastTime = 0;
unsigned long timerDelay = 2000; //2 sec timer delay

void setup() {
    // Start Serial port
    Serial.begin(115200);
    if (wifi_mode == "STA"){// STA mode setting
        ssid = "LAB_3301";      // "LAB_I3301"; // "I2313";"HomeResort3F";
        password = "KSUilu@i3301";  //"KSUilu@i3301"; //"0928474616";"j0928474616g";
    } else { // AP mode
        ssid = "MyWebServerWiFi";
        password = "123456789";
    }

    lcd_init();
    // initialize SPIFFS File System
    initFS();
    // initialize WIFi
    initWiFi();

    dht.begin();
    // start web server with SPIFFS
    initWebServer();
    // initialize WebEvent connection on the gateway
    initWebEvent();
}

void loop() {
    // update DHT data based on webevents by Server-sent-events (SSE) with the client sse_dht.js
    // Send Events to the client with the Sensor Readings Every 2 seconds
    float tmp,humid;

    unsigned long delta = millis() - lastTime;
    byte time_interval = int(delta/1000);

    if (delta > timerDelay) {
      // send event with target type: "NULL"/ or "message" and ping_data to check on the client side that the server is alive
      // the event will be intercepted by EventListerned in the client (sse_dht.js) with the target type: 'message'
      String ping_data = String() + "ping time@" + String(millis());
      events.send(ping_data.c_str(), "message", millis()); 
        
      Serial.println(String() + "WebEvent: updating target data every " + time_interval + " seconds");
      // Server-Sent-Event (SSE) with the event target type: 
      // the event will be intercepted by EventListerned in the client (sse_dht.js) with the target type:'web_event_new_readings'
      // The send() method accepts a variable of type char, so we need to use the c_str() method to convert the variable.
      try{
        String json_string = readDHTData();

        JSONVar dht_data = JSON.parse(json_string);
        tmp = atof(dht_data["Temperature"]);
        humid = atof(dht_data["Humidity"]);
        events.send(json_string.c_str(), "web_event_new_readings", millis());
        lastTime = millis(); // update the lastTime
      } catch (const char *e) { 
         Serial.println(String()+ "ERROR: "+ e);
      }
        String l1_text = String() + "temp: "+ tmp + (char)223 + "C";
        String l2_text = String() + "humi: " + humid + " %";


        lcd_print(l1_text,l2_text);
      //String target_data = String() + "Hello from ESP32: target data update every " + time_interval + " seconds";
      //events.send(target_data.c_str(), "web_event_new_readings", millis());
      //lastTime = millis();  // update the lastTime
      
    }
}


